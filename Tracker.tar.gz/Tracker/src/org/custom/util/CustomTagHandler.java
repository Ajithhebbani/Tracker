package org.custom.util;

import java.util.ArrayList;
import javax.servlet.jsp.JspException;  
import javax.servlet.jsp.JspWriter;  
import javax.servlet.jsp.tagext.TagSupport;


public class CustomTagHandler extends TagSupport{
	private String id;  
	private String table;  
	private String pageNo;    
	public String getPageNo() {
		return pageNo;
	}
	public void setPageNo(String pageNo) {
		this.pageNo = pageNo;
	}
	public void setId(String id) {  
	    this.id = id;  
	}  
	public String getId() {
		return id;
	}
	public void setTable(String table) {  
	    this.table = table;  
	}  
	
	private static final long serialVersionUID = 1L;

	public int doStartTag()throws JspException{  
	    JspWriter out=pageContext.getOut();  
	    
	    try{   
	      /*  Class.forName("oracle.jdbc.driver.OracleDriver");  
	        Connection con=DriverManager.getConnection(  
	                 "jdbc:oracle:thin:@localhost:1521:xe","system","oracle");  
	        PreparedStatement ps=con.prepareStatement("select * from "+table+" where id=?");  
	        ps.setInt(1,Integer.parseInt(id));  
	        ResultSet rs=ps.executeQuery();  */
	    	ActorData actorData = new ActorData();
	        ArrayList<ActorData> actordata =  actorData.loadData();
	    	
	        String spageid=getId(); 
	        System.out.println("spageid >>>>>"+ spageid + "<<<<<<spageid");
	        if(spageid != null && "".equals(spageid) ) {
	        	spageid="1";
	        }
	    	int pageid = Integer.parseInt(spageid);  
	    	System.out.println(pageid +" >>>>pageidpageidpageidpageidpageidpageidpageid");
	    	int total=5;
	    	int ll=0,rl=0;
	    	
	    	if(pageid==1){
	    		ll=0;
	    		rl=5;
	    	}  
	    	else{  
//	    	    pageid=pageid-1;  
//	    	    pageid=pageid*total+1;  
				ll=(pageid-1)*total+1;
				rl=pageid*total;
	    	} 
	        
	        
	        //column name  
	        out.write("<table border='1'>");  
	        out.write("<tr>");  
	            out.write("<th>Actor Name</th><th>TV Show</th><th>Email ID</th>");  
	        out.write("</tr>");  
	        //column value  
	          
            for(int index = ll ; index<=rl && index < actordata.size() ; index++ ) {
//            for(ActorData ad : actordata){  
            	out.write("<tr>");  
            	//out.write("<td>"+ad.getUserName()+"</td><td>"+ad.getTvShow()+"</td><td>"+ad.getEmailId()+"</td>");  
            	out.write("<td>"+actordata.get(index).getUserName()+
            			"</td><td>"+actordata.get(index).getTvShow()+
            			"</td><td>"+actordata.get(index).getEmailId()+"</td>");  

            	out.write("</tr>");
            }  
              
	        out.write("</table>");  
	          
	    }catch(Exception e)
	    {
	    	e.printStackTrace();
	    }  
	    return SKIP_BODY;  
	}  
	

}
