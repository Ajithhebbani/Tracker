package org.servlet.track;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.custom.util.CustomTagHandler;

public class InitServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String pageno = request.getParameter("page");
		request.setAttribute("pageno",pageno);
		doPost(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		  // Forward to /WEB-INF/views/homeView.jsp
	       // (Users can not access directly into JSP pages placed in WEB-INF)
//	       RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/index.html");
//			CustomTagHandler cth = new CustomTagHandler();
//			System.out.println(">>>>" + request.getParameter("page"));
//			cth.setPageNo(request.getParameter("page"));
		
			System.out.println(">>>>>>>>>>>>>>>>>"+request.getAttribute("pageno")+" ???????????");
	       RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/jsp/session-counts.jsp");
	       dispatcher.forward(request, response);
		
		
//		response.setContentType("text/html");
//		response.sendRedirect("./index.html");
	}
}
